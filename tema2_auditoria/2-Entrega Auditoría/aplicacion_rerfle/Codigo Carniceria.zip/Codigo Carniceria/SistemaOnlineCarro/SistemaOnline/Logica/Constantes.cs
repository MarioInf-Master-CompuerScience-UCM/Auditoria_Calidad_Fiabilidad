﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SistemaOnline.Logica
{
    public class Constantes
    {
       public int Estado_Separado = 1;
       public int Estado_Comprado = 2;
       public int Estado_Liberado = 3;
    }
}